<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;
function random_num($length)
{
    $text="";
    if($length < 5)
    {
        $length=5;
    }

    $len = rand(4,$length);
    for ($i=0; $i < $len; $i++) { 
        # code...

        $text .= rand(0,9);
    }
    return $text;
}

require 'dbh.php';

if(isset($_POST['submit'])){

    $submitbutton=$_POST['submit'];
    $name=$_POST['username'];
    $housenumber=$_POST['residency'];
    $email=$_POST['email'];
    $idnumber=$_POST['idnumber'];
    $phonenumber=$_POST['phonenumber'];
    $payed=$_POST['payed'];
    $myemail="reyclamar06@gmail.com";
    $table='tenants';
    $booking_id=random_num(10);
    $status='chaked in';
    $word='Kipchumbaroy-1';


    if((!empty($name))&&(!empty($housenumber))&&(!empty($email))&&(!empty($idnumber))&&(!empty($phonenumber)))
{

    if(mysqli_query($connection,"INSERT INTO $table (name,house_number,email,id_number,phone_number,payed,bookingid,status) VALUES ('$name','$housenumber','$email','$idnumber','$phonenumber','$payed','$booking_id','$status')")){


    mysqli_query($connection,"UPDATE rooms SET state='occupied' WHERE room_number=$housenumber");

    }
    

    header('location:index.php?code='.$booking_id);
}
else{
    echo $name.'<br/>';
    echo $residency.'<br/>';
    echo $email.'<br/>';
    echo $idnumber.'<br/>';
    echo$phonenumber.'<br/>';
}
}