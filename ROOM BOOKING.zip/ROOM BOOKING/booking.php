<?php
require 'header.php';
require 'sidebar.php';
?>
           

            <div class="center">
            <?php
                    $value=$_GET['id'];
            ?>
            <!--video section starts-->
            <div class="login-page">
                <div class="form">
                    <p class="text" style="color: rgb(0, 255, 85); padding-bottom: 1em;">Room <?php echo $value;?> booking</p>
                  <form class="register-form" action="upload.php" method="POST">
                    <input type="text" name="username" placeholder="Name" required/>
                    <input type="text" name="residency" placeholder="Residency" value="<?php echo $value;?>" required style="display:;"/>
                    <input type="text" name="email" placeholder="Email address" required/>
                    <input type="number" name="idnumber" placeholder="Id.number" required/>
                    <input type="tel" name="phonenumber" placeholder="Phone number" required/>
                    <input type="number" name="payed" placeholder="Amout paid" required/>
                    <input style="background: rgb(13, 197, 83);  padding-bottom:2em;" class="press" type="submit" name="submit" value="Book"/>
                  </form>
                  <a href="index.php"><button style="background: rgb(13, 197, 83);" class="press">back</button></a>
                </div>
              </div>
            <!--video section ends-->
        </div>
        </div>

    <!--main body ends-->

    <script src="index.js"></script>
</body>
</html>