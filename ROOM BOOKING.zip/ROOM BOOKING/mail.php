<?php


require_once 'phpmailer/src/Exception.php';
require_once 'phpmailer/src/PHPMailer.php';
require_once 'phpmailer/src/SMTP.php';

$mail = new PHPMailer(true);

$alert = '';

try{
    $mail->isSMTP();
    $mail->SMTPDebug = 2;
    $mail->CharSet = "UTF-8";
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = $myemail; // Gmail address which you want to use as SMTP server
    $mail->Password = $word; // Gmail address Password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = '587';

    $mail->setFrom($myemail); // Gmail address which you used as SMTP server
    $mail->addAddress($email); // Email address where you want to receive emails (you can use any of your gmail address including the gmail address which you used as SMTP server)

    $mail->isHTML(true);
    $mail->Subject = 'Booking successful';
    $mail->Body = "<p>Hello $name<br>
                    You have successfully booked room $housenumber,<br>
                    Your visitor id is <a href='#'>$booking_id </a>,
                    Amount payed $payed </p>";

    $mail->send();
    $alert = '<div class="alert-success">
                <span>Message Sent! Thank you for contacting us.</span>
                </div>';
} catch (Exception $e){
    $alert = '<div class="alert-error">
                <span>'.$e->getMessage().'</span>
            </div>';
}

if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'Message has been sent';
}