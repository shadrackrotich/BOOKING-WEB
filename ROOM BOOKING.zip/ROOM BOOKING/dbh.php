<?php

$host = "localhost";
$user = "root";
$password = "roy";
$dbase = "booking_system";



//create connection
$connection = mysqli_connect($host,$user,$password,$dbase);


if(!$connection)
{
    die('could not connect:'.mysql_error());
}