<?php
require 'header.php';
require 'sidebar.php';
?>

<?php


require 'dbh.php';

    $housenumber=$_GET['id'];

    $sql="SELECT * from tenants WHERE house_number=$housenumber and status='chaked in';";
    $res= mysqli_query($connection,$sql);
    $row=mysqli_fetch_assoc($res);
    $name=$row['name'];
    $house_number=$row['house_number'];
    $email=$row['email'];
    $idnumber=$row['id_number'];
    $phonenumber=$row['phone_number'];
    $payed=$row['payed'];
    $bookingid=$row['bookingid'];
    $status=$row['status'];
    

?>




            <div class="center">
            <!--video section starts-->
            <div class="login-page">
                <div class="form">
                    <p class="text" style="color: rgb(0, 255, 85); padding-bottom: 1em;">Occupant Details</p>
                    <style>
                        .table{
                            color: white;
                        }
                        .table tr td{
                            border: 2px solid rgb(29, 160, 73);
                            text-align:left;
                        }
                    </style>
                    <table class='table'>
                        <tr><td><b>Name: </b></td> <td><?php echo $name; ?></td></tr>
                        <tr><td><b>Id number:</b> </td> <td><?php echo $idnumber; ?></td></tr>
                        <tr><td><b>Phone No:</b></td> <td><?php echo $phonenumber; ?></td></tr>
                        <tr><td><b>Email:</b> </td> <td><?php echo $email; ?></td></tr>
                        <tr><td><b>Balance:</b></td> <td><?php echo $payed; ?></td></tr>
                        <tr><td><b>Room No: </b></td> <td><?php echo $house_number; ?></td></tr>
                    </table>
                </div>
              </div>
            <!--video section ends-->
        </div>
        </div>

    <!--main body ends-->

    <script src="index.js"></script>
</body>
</html>