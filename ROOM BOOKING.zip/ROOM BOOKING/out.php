<?php
require 'header.php';
require 'sidebar.php';
use PHPMailer\PHPMailer\PHPMailer;
?>

<?php


require 'dbh.php';
$res="8";

if(isset($_POST['submit'])){
    $bookingid=$_POST['bookingid'];

    $sql="SELECT * from tenants WHERE bookingid=$bookingid;";
    $res= mysqli_query($connection,$sql);
    $row=mysqli_fetch_assoc($res);
    $name=$row['name'];
    $housenumber=$row['house_number'];
    $email=$row['email'];
    $id=$row['id_number'];
    $phonenumber=$row['phone_number'];
    $balance=$row['payed'];
    $bookingid=$row['bookingid'];
    $status=$row['status'];
    $myemail="reyclamar06@gmail.com";

    if($status==="chaked out"){
        echo '<script> 
        alert("you already chaked out");
      </script>';
    }
    else{

    mysqli_query($connection,"UPDATE rooms SET state='free for occupation' WHERE room_number=$housenumber");
    mysqli_query($connection,"UPDATE tenants SET status='chaked out' WHERE house_number=$housenumber");


    header('location:index.php');

        }
    
}
?>

            <div class="center">
            <!--video section starts-->
            <div class="login-page">
                <div class="form">
                    <p class="text" style="color: rgb(0, 255, 85); padding-bottom: 1em;">Chake out</p>
                  <form class="register-form" action="" method="POST">
                      <input type="text" name="bookingid" placeholder="Booking ID">
                    <input style="background: rgb(13, 197, 83); padding-bottom:2em;" class="press" type="submit" name="submit" value="Chake Out"/>
                  </form>
                  <a href="index.php"><button style="background: rgb(13, 197, 83);" class="press">back</button></a>
                </div>
              </div>
            <!--video section ends-->
        </div>
        </div>

    <!--main body ends-->

    <script src="index.js"></script>
</body>
</html>