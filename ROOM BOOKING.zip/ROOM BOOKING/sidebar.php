    <!--Side bar starts-->
    <div class="side-bar">

<div class="side-bar-categories">
    <a href="index.php">
    <div class="side-bar-category">
        <span>Home</span>
    </div>
    </a>
<hr/>
    <a href="freerooms.php">
    <div class="side-bar-category">
        <span>Free Rooms</span>
    </div>
    </a>
    <hr/>

    <a href="out.php">
    <div class="side-bar-category">
        <span>Chake out</span>
    </div>
    </a>
    <hr/>
</div> 
</div>
<!--side bar ends-->