<?php
require 'header.php';
require 'sidebar.php';
?>
           
           <!--video section starts-->
                <div class="videos">
                    <h1>Free Rooms</h1>
                    <div class="video-container">
                    <?php

require_once 'dbh.php';

$sql='SELECT * FROM rooms where state="free for occupation"';
$res=mysqli_query($connection,$sql);

while($row=mysqli_fetch_assoc($res)){
    $roomnumber=$row['room_number'];
    $state=$row['state'];
    $price=$row['price'];

?>
                       <!--single video section starts-->
                       <?php 
                                        if($state=='occupied'){
                                            $color='red';
                                            $url='details.php?id='.$roomnumber;
                                        }
                                        else{
                                            $color='';
                                            $url='booking.php?id='.$roomnumber;
                                        }
                                    ?>
                       <a href="<?php echo $url; ?>" name="url">
                        <div class="video1">
                            <div class="video-thumbnail">
                               <p><h1 style="color:<?php echo $color;?>;">Room <?php echo $roomnumber;?> </h1></p>
                            </div> 
                            <div class="video-details">
                                
                                <div class="title">
                                   
                                    <h3 style="color:<?php echo $color;?>;"><?php echo $state; ?></h3>
                                    <span>Monthly price|ksh<?php echo $price; ?></span>
                                </div>
                            </div>
                        </div>
                        </a>
                       <!--single video section ends-->
                       <?php } ?>
                    
                    </div>
                </div>
            <!--video section ends-->

        </div>

    <!--main body ends-->

    <script src="index.js"></script>
</body>
</html>